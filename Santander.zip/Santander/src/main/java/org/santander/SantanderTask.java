package org.santander;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"org.santander.*"})
public class SantanderTask {
    public static void main(String[] args) {
        SpringApplication.run(SantanderTask.class, args);
        SantanderTask santanderTask = new SantanderTask();
        santanderTask.onMessage("106, EUR/USD, 1.1000,1.2000,01-06-2020 12:01:01:001");
    }

    //This method will subscribe to stream of messages to listen
    // live market prices
    public void onMessage(String message) {
        String[] inputMessage = message.split(",");

        //bid price
        double bidPrice = Double.parseDouble(inputMessage[2].trim());

        //ask price
        double askPrice = Double.parseDouble(inputMessage[3].trim());

        //apply margin
        double bidMargin = applyBidMargin(bidPrice);
        double askMargin = applyAskMargin(askPrice);

        // publish adjusted price to Rest api
        // create the api under controller package
        //RestTemplate restTemplate = new RestTemplate();
        //restTemplate.exchange("rest endpoint",HttpMethod.POST,requestEntity,String.class);

        System.out.println("Calculated Bid price:" + bidMargin);
        System.out.println("Calculated Ask price:" + askMargin);

        System.exit(0);
    }

    public double applyBidMargin(double bidPrice) {
        return bidPrice - ((bidPrice * 0.1) / 100);
    }

    public double applyAskMargin(double askPrice) {
        return askPrice + ((askPrice * 0.1) / 100);
    }
}
